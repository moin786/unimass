    <div class="full-footer">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
        </div>
        <strong>Copyright &copy; <?php echo date("Y"); ?>, All rights reserved by NEXTGENiT. Design and Developed by <a href="http://nextgenitltd.com/" target="_blank">NEXTGENiT Ltd.</a></strong>
    </div>

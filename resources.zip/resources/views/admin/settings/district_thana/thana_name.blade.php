<div class="form-group" >
	<label>Thana Name <span class="text-danger">*</span></label>
	<input type="text" class="form-control" id="Thana" name="Thana" title="Thana Name" placeholder="Thana Name" value="{{!empty($data->thana_name)?$data->thana_name: ''}}">
</div>
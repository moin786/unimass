<th class="text-center">Lead ID</th>
<th class="text-center">Create Date</th>
<th class="text-center">Customer</th>
<th class="text-center" width="100">Mobile</th>
<th class="text-center">Project Details</th>
<th class="text-center">Created By</th>
<th class="text-center">Assigned To</th>
<th class="text-center">Stage</th>
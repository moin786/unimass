<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProjectScheduleCollection extends Model
{
    //
	protected $table = 'project_schedule_collectoins';
	protected $primaryKey = 'id';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeadFollowupAttribute extends Model
{
    //
    protected $table = 't_leadfollowup_attribute';
	protected $primaryKey = 'followup_attr_pk_no';
}

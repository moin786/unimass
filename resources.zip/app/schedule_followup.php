<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class schedule_followup extends Model
{
    //

	protected $table = 'schedule_followup';
	protected $primaryKey = 'id';
}

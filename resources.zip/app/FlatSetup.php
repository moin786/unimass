<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FlatSetup extends Model
{
    protected $table = 's_projectwiseflatlist';
	protected $primaryKey = 'flatlist_pk_no';

}

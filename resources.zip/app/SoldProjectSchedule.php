<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SoldProjectSchedule extends Model
{
    //
	protected $table = 'sold_project_schedules';
	protected $primaryKey = 'id';
}

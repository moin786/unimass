<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeadLifeCycle extends Model
{
	protected $table = 't_leadlifecycle';
	protected $primaryKey = 'leadlifecycle_pk_no';

}

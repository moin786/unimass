<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeadFollowUp extends Model
{
	protected $table = 't_leadfollowup';
	protected $primaryKey = 'lead_followup_pk_no';
}

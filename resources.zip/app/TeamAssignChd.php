<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamAssignChd extends Model
{
    protected $table = 't_teambuildchd';
    protected $primaryKey = 'teammemchd_pk_no';
}

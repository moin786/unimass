<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeadHistory extends Model
{
    protected $table = 't_leadshistory';
	protected $primaryKey = 'leadhistory_pk_no';
}

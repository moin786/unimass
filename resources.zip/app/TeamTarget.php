<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeamTarget extends Model
{
    protected $table = 't_teamtarget';
    protected $primaryKey = 'target_pk_no';

}
